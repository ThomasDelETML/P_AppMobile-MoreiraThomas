﻿namespace MauiApp1.Models
{
    public class Auteur
    {
        public int Auteur_Id { get; set; }
        public string? Nom { get; set; }
    }
}
