﻿namespace MauiApp1.Models
{
    public class Categorie
    {
        public int Categorie_Id { get; set; }
        public string? Libelle { get; set; }
    }
}
