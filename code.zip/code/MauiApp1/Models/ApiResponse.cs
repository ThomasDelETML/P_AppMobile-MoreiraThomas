﻿namespace MauiApp1.Models
{
    public class ApiResponse
    {
        public string? Message { get; set; }
        public List<Livre>? Data { get; set; }
    }
}
